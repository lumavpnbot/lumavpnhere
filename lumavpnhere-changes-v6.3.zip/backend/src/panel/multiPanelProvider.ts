import type { PanelClient, PanelProvider } from './types'

/**
 * Несколько серверов (стран) как один. Каждая страна у H1 это отдельная
 * панель со своим API и токеном. Клиента создаём на всех, а подписку
 * пользователю склеиваем в одну в /sub/:token.
 *
 * Первая панель главная: по ней считаем срок, трафик и устройства.
 * Если какая-то страна недоступна, выдача на остальных не ломается.
 */
export function createMultiPanelProvider(panels: PanelProvider[], logFn: (msg: string) => void = console.warn): PanelProvider {
  // Последняя ошибка по каждой стране, видна в /health (без секретов, только текст ошибки).
  const lastErrors: Record<string, { at: string; error: string }> = {}
  const log = (msg: string) => {
    logFn(msg)
    const m = /^\[panel ([^\]]+)\] (.*)$/.exec(msg)
    if (m) lastErrors[m[1]] = { at: new Date().toISOString(), error: m[2] }
  }
  async function each<T>(fn: (p: PanelProvider) => Promise<T>, what: string) {
    const results = await Promise.allSettled(panels.map(fn))
    results.forEach((r, i) => {
      if (r.status === 'rejected') log(`[panel ${panels[i].countries.join(',') || i}] ${what}: ${(r.reason as Error)?.message}`)
    })
    return results
  }

  return {
    kind: 'multi',
    countries: panels.flatMap((p) => p.countries),

    async provision(params) {
      const results = await each((p) => p.provision(params), 'provision')
      const first = results[0]
      if (first.status === 'rejected') throw first.reason
      const ok: PanelClient[] = results.flatMap((r) => (r.status === 'fulfilled' ? [r.value] : []))
      return { ...first.value, upstreamSubscriptionUrls: ok.flatMap((c) => c.upstreamSubscriptionUrls), links: ok.flatMap((c) => c.links ?? []) }
    },

    async getClient(tgId) {
      const results = await each((p) => p.getClient(tgId), 'getClient')
      const main = results[0].status === 'fulfilled' ? results[0].value : null
      if (!main) return null

      // Новая страна добавлена позже, чем пользователь получил доступ: досоздаём
      // клиента на ней с тем же сроком и лимитами, что на главной панели.
      if (main.enabled && main.expiresAt && main.expiresAt > new Date()) {
        await Promise.all(
          results.map(async (r, i) => {
            if (i === 0 || (r.status === 'fulfilled' && r.value)) return
            try {
              const c = await panels[i].provision({
                tgId,
                expiresAt: main.expiresAt!,
                trafficLimitGb: main.trafficLimitGb,
                deviceLimit: main.deviceLimit,
              })
              results[i] = { status: 'fulfilled', value: c }
            } catch (e) {
              log(`[panel ${panels[i].countries.join(',')}] backfill: ${(e as Error).message}`)
            }
          }),
        )
      }

      const alive = results.flatMap((r) => (r.status === 'fulfilled' && r.value?.enabled ? [r.value] : []))
      return { ...main, upstreamSubscriptionUrls: alive.flatMap((c) => c.upstreamSubscriptionUrls), links: alive.flatMap((c) => c.links ?? []) }
    },

    async disable(tgId) {
      await each((p) => p.disable(tgId), 'disable')
    },

    async remove(tgId) {
      await each((p) => p.remove(tgId), 'remove')
    },

    async describe() {
      const out: Record<string, unknown> = {}
      await Promise.all(
        panels.map(async (p, i) => {
          out[p.countries[0] ?? String(i)] = p.describe ? await p.describe().catch((e: Error) => ({ error: e.message })) : null
        }),
      )
      return { panels: out, lastErrors }
    },
  }
}
